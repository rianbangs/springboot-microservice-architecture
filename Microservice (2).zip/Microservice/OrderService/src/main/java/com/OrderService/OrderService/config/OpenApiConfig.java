package com.OrderService.OrderService.config;

public class OpenApiConfig
{

}
